<?php

	class userModel extends CI_Model{

			public function authenticate($data){
				$result = $this->db->get_where('users',$data);
				return $result->num_rows();
			}
	}

?>