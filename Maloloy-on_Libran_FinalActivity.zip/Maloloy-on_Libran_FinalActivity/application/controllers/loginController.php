<?php

	class loginController extends CI_Controller{

		public function __construct(){

			parent::__construct();
			$this->load->model('userModel','um');


		}

		public function index(){
			
               
        $this->load->view('login_view');
                
                
		}


		public function login(){
		$this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->form_validation->set_rules('username', 'Username', 'required',array('required' => 'You must provide a %s.'));
        $this->form_validation->set_rules('password', 'Password', 'required',array('required' => 'You must provide a %s.'));
        if ($this->form_validation->run() == FALSE)
        {
            $this->load->view('login_view');
        }else
        {


			$username = $_POST['username'];
			$password = $_POST['password'];

			$data = array(
				"username" => $username,
				"password" => $password,
				
			);

			
			$result = $this->um->authenticate($data);
			

			if($result > 0){
				$this->session->user=array(
					"username" => $username,	
				);
				redirect(base_url("index.php/homecontroller/"));
			} else{
				
			
				

				redirect(base_url("index.php/loginController/"));
						
				
				
				
			}

		}
	}

		public function logout(){

			$this->session->sess_destroy("user");

			redirect(base_url("index.php/loginController/index"));
		}

	}


?>