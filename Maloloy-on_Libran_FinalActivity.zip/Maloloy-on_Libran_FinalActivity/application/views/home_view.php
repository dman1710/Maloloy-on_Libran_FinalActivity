<html>
	<header>
		<title> <?php echo $this->session->user["username"] ?> HomePage</title>
	</header>

	<body>
		<br>
		<br>
			<?php echo form_open_multipart('upload/do_upload');?>
		<center>
			<h2>Welcome <?php echo $this->session->user["username"]?>! </h2><br><br>

			<input type="file" name="userfile" size="20" />

			<br><br>

			<input type="submit" value="Upload" />
			<br><br>


			<a href="<?php echo base_url("index.php/logincontroller/logout"); ?>"> Logout</a><br>
		</center>
	</body>
</html>
