<html>
	<head>
			<title>Login</title>
	</head>
	
	<body>
		<center>
		<?php echo validation_errors(); ?>

		<?php echo form_open('logincontroller/login'); ?>


		
		<form method="POST" action="login">
			<br>
			Username: <input type="text" name="username" placeholder="Input username"><br>
			Password: <input type="password" name="password" placeholder="Input Password"><br><br>

					  <input type="submit" name="btnLogin" value="Login"><br>
			
		</form>
		</center>
		
			
	</body>
	
</html>
